# boonex-on-kodi
Boonex dolphin module to connect to your favourite social site through kodi
This demo will be connected to demo.boonex.com or demo.18play.be to explore functionalities
Username: Kangeroo
Password: dolphin
Contact me if you are intrested
Berichtencentrum@mail.com
